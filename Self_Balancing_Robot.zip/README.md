# BalancedRobot
This repository has code and diagram for arduino based balanced robot

We are going to learn how to make Balanced Robot using Arduino.
The main logic behind Balanced Robot is to read the inclination of robot using sensor(In our case MPU6050) and adjust the motor powers and direction accordingly.

